import { css } from 'emotion';

export const content = css`
  margin: 2rem;
`;
