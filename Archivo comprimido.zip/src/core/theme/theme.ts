import { createMuiTheme, Theme } from '@material-ui/core/styles';

const defaultTheme = createMuiTheme();

export const theme: Theme = defaultTheme;
